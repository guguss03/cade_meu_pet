<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Login</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body background="img/background.jpg">
    <div class="Conteudo" width="100%" heigth="100%">
        <div class="BlocoDeLogin">
            <div class="Dados_do_Usuario">
                <h1 >Olá Amante de Pets, Bem vindo de volta!</h1>
                <div class="Preencher_dados">
                <input type="email" placeholder="Digite seu email..." size="30"><br><br>
                <input type="password" placeholder="Digite sua senha..." size="30"><br><br>
                </div>
                <div class="LoginBottom">
                    <a href="index.html">
                <button class="button1">LOGIN</button>
                    </a>
                </div>
            </div> 
        </div>
    </div>

    <div class="Conteudo2" width="100%" heigth="100%">
        <img src="img/semfundo.jpg" alt="semfundo.jpg" width="100%" height="100%">
    </div>

    </div>        
</body>
</html>